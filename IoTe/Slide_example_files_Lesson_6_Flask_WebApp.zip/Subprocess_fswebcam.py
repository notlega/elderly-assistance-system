import subprocess
subprocess.run(["fswebcam","static/figure.jpg"])
