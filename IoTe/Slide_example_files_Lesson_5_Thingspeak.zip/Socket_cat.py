#Server
import socket
HOST='172.23.26.251' #ip address of server
PORT=50007 #port number of server
s=socket.socket(socket.AF_INET,socket.SOCK_STREAM) #TCP
s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
s.bind((HOST,PORT))
s.listen(1) #listen for connection from client
conn,addr=s.accept() #when client connects, accept / complete the connection
print ('connected by',addr) #debug print
while (True):
    data=conn.recv(1024) #receive a number from client
    print(data) #debug print
    if not data:
        break
    conn.sendall(b'333') #send a number to client, b is to convert to utf-8
conn.close() #close connection with client

