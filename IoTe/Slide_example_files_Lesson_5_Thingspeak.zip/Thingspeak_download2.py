import requests
import json

#uploaded values were: [23,24,25,23,21,22,24,26,27,26]
#uploaded values were: [55,57,60,59,62,66,70,68,66,65]

resp=requests.get("https://api.thingspeak.com/channels/645078/feeds.json?results=10") #read all fields, 10 values
#resp=requests.get("https://api.thingspeak.com/channels/645078/fields/2.json?results=10") #to read only field 2, 10 values

print(resp.text)
results=json.loads(resp.text) #convert json into Python object

for x in range(10):
    print("Downloaded sample",x,": temperature =",results["feeds"][x]["field1"],", humidity =",results["feeds"][x]["field2"])


