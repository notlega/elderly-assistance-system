import requests

resp=requests.post("https://api.thingspeak.com/apps/thingtweet/1/statuses/update",
                   json={"api_key":"SZEVPJZFGCTU8375","status":"This tweet is posted by PYthon code in a Raspberry Pi"})

#resp=requests.post("https://api.thingspeak.com/apps/thingtweet/1/statuses/update?api_key=SZEVPJZFGCTU8375&status=hello there!")
