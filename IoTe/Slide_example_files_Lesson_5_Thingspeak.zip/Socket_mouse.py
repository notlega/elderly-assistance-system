#Client
import socket
HOST='172.23.26.251' #ip address of server
PORT=50007 #port number of server
s=socket.socket(socket.AF_INET,socket.SOCK_STREAM) #TCP
s.connect((HOST,PORT)) #connect to server
s.sendall(b'168') #send a number to server, b is to convert to utf-8
data=s.recv(1024) #receive a number from server
print(data) #debug print
s.close #close connection with server
