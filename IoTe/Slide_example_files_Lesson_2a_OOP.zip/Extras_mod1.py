# file name: mod1.py

count = 8 # a variable

def add1(num): # a function
    return num+1

class myclass: # a class
    pass # will not go into details
