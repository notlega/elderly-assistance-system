# file name: myprog.py

import mod1

print (mod1.count)
