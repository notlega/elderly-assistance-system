from tkinter import *
top=Tk() #create the root / base window
L=Label(top,text="Hello World!") #create a label with words
L.pack() #put the label into the window
top.mainloop() #start the event loop
